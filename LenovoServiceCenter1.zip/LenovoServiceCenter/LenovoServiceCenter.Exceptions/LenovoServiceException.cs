﻿using System;
using System.Runtime.Serialization;

namespace LenovoServiceCenter.Exceptions
{
    [Serializable]
    public class LenovoServiceException : Exception
    {
        public LenovoServiceException()
        {
        }

        public LenovoServiceException(string message) : base(message)
        {
        }

        public LenovoServiceException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected LenovoServiceException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}