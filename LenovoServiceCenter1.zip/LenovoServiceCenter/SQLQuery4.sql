use Training_19Sep18_Pune

create schema lenovo

create table lenovo.Service_Details
(
serviceID varchar(6) primary key,
ServiceDate date not null,
OwnerName varchar(30),
Contact varchar(10),
DeviceType varchar(15),
serialno varchar(16),
IssueDescription varchar(200)
)

create proc lenovo.uspAddRequest
(
@Id varchar(6),
@date date,
@On varchar(30),
@Cn varchar(10),
@Dt varchar(20),
@Sn varchar(16),
@descp varchar(250)
)
as
begin
	insert into lenovo.Service_Details
	values(@Id,@date,@On,@Cn,@Dt,@Sn,@descp)
	
end

create proc lenovo.uspGetProducts
as
begin
	select * from lenovo.Service_Details
end


select * from lenovo.Service_Details

